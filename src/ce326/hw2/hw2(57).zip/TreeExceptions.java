package ce326.hw2;

public class TreeExceptions extends java.lang.Exception
{
	//String myException = null;
	public TreeExceptions(String myException)
	{
		//this.myException = myException;
		super(myException);
	}
	
	//@Override
//	public String toString()
//	{
//		return myException;
//	}
}
