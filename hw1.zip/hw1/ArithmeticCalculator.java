package ce326.hw1;

public class ArithmeticCalculator 
{
	
	Tree_create newTree;
	//tree_node root;
	//int nodeCount;
	public ArithmeticCalculator (String input)
	{
		//Tree_create newTree;
		newTree = new Tree_create(5);
		newTree.root =  newTree.insert(input);
	}
	
	
	
	public String toDotString()
	{
		String dotText;
		dotText = newTree.buildGraphvizTree(newTree.root);
		
		return dotText;
	}
	
	public double calculate()
	{
		double result;
		result = newTree.evaluate(newTree.root);
		
		return result;
	}
	
	
	
}
